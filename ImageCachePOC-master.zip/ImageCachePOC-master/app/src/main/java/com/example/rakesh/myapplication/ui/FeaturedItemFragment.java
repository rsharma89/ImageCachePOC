package com.example.rakesh.myapplication.ui;

import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.Spinner;

import com.example.rakesh.myapplication.InteractorImpl;
import com.example.rakesh.myapplication.R;
import com.example.rakesh.myapplication.adapter.CategoryListAdapter;
import com.example.rakesh.myapplication.adapter.ProductListAdapter;
import com.example.rakesh.myapplication.helper.Util;
import com.example.rakesh.myapplication.model.Content;
import com.example.rakesh.myapplication.model.ProductAttribute;
import com.example.rakesh.myapplication.presenter.FeaturedItemFragmentPresenterImpl;
import com.example.rakesh.myapplication.presenter.FeaturedItemPresenter;

import java.util.ArrayList;

/**
 * Created by rakesh on 29/01/18.
 */

public class FeaturedItemFragment extends Fragment implements FeaturedItemFragmentListener{

    private Spinner categorySpinner;
    private FeaturedItemPresenter featuredItemPresenter;
    private Context mContext;
    private RecyclerView recyclerView;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.featured_item,container,false);
        featuredItemPresenter = new FeaturedItemFragmentPresenterImpl(this,new InteractorImpl());
        featuredItemPresenter.fetchCategoryList();
        featuredItemPresenter.fetchProductData("101");
        initUI(view);
        return view;
    }

    private void initUI(View v) {
        categorySpinner = (Spinner) v.findViewById(R.id.category_list);
        recyclerView = (RecyclerView)v.findViewById(R.id.featured_item_view);
        recyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(mContext,2);
        recyclerView.setLayoutManager(layoutManager);
    }

    @Override
    public void loadCategoryData(ArrayList<Content> list) {
        CategoryListAdapter categoryListAdapter = new CategoryListAdapter(mContext,list);
        categorySpinner.setAdapter(categoryListAdapter);
    }

    @Override
    public void showProgressDialog() {
        Util.showDialog();
    }

    @Override
    public void hideProgressBar() {
        Util.hideDialog();
    }

    @Override
    public void loadProductData(ArrayList<ProductAttribute> productList) {
        ProductListAdapter productListAdapter = new ProductListAdapter(mContext,productList);
        recyclerView.setAdapter(productListAdapter);
    }

}
