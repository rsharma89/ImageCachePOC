package com.example.rakesh.myapplication;

/**
 * Created by rakesh on 29/01/18.
 */

public interface CallBackListener {

    public void onSuccess(Object data);
    public void onFailure();
}
