package com.example.rakesh.myapplication.presenter;

/**
 * Created by rakesh on 29/01/18.
 */

public interface FeaturedItemPresenter {

    void fetchProductData(String id);
    void fetchCategoryList();
}
