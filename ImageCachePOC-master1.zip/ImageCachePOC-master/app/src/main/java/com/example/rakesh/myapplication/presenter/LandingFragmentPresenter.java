package com.example.rakesh.myapplication.presenter;

/**
 * Created by rakesh on 29/01/18.
 */

public interface LandingFragmentPresenter {

    public void updateCoutrySpinner();
    public void mapCountryListToSpiner();
    public void onApplyBtnClicked();
}
