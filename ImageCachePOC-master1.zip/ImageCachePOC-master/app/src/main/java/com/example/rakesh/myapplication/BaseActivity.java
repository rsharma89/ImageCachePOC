package com.example.rakesh.myapplication;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by 409992 on 1/30/2018.
 */

public class BaseActivity extends AppCompatActivity {


}
